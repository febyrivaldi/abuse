<?php

namespace tests\Api\Ticket;

use tests\Api\ShowTestHelper;
use tests\TestCase;

class ShowTest extends TestCase
{
    use ShowTestHelper;

    const URL = '/api/v1/tickets';
}
