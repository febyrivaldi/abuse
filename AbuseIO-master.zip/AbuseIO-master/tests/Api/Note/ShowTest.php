<?php

namespace tests\Api\Note;

use tests\Api\ShowTestHelper;
use tests\TestCase;

class ShowTest extends TestCase
{
    use ShowTestHelper;

    const URL = '/api/v1/notes';
}
