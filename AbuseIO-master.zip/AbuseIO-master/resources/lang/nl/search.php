<?php

/**
 * Translations for Search.
 */
return [
    // Headers

    // Buttons
    'button.search' => 'Zoek',

    // Miscellaneous
    'customer_code' => 'Klant Code',
    'customer_name' => 'Klant Naam',
];
