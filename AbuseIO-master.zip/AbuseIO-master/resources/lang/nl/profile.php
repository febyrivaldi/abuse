<?php

/**
 * Translations for Profile.
 */
return [
    'password'              => 'Wachtwoord',
    'password_confirmation' => 'Wachtwoord (herhaal)',
];
