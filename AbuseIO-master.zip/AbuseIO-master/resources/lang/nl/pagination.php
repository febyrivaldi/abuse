<?php

/**
 * Translations for Pagination.
 */
return [

    'previous' => '&laquo; Vorige',
    'next'     => 'Volgende &raquo;',

];
