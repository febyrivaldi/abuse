<?php

/**
 * Translations for Analytics.
 */
return [
    // Headers

    // Buttons
    //'button.<name>'     => 'Translation'

    // Miscellaneous
    //'<custom_trans>'    => 'Translation',
];
