<?php

/**
 * Translations for Brands.
 */
return [
    // Headers
    'header.new'    => 'Νέο Brand',
    'header.edit'   => 'Επεξεργασία Brand',
    'header.detail' => 'Λεπτομέρειες brand για',

    // Buttons
    'button.new_brand' => 'Νέο Brand',

    // Miscellaneous
    'no_brands' => 'Δεν υπάρχουν brands',
    'logo'      => 'Εταιρικό logo', ];
