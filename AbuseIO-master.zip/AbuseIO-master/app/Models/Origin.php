<?php

namespace AbuseIO\Models;

/**
 * Class Origin.
 *
 * API Wrapper for incident enriching the incident with ticket data from the parent
 */
class Origin
{
    /**
     * @var
     */
    public $parentTicketID;
}
